hw03
===

### 41247022S 林德恩

---

## How to build my code
在 HW03 directory 下 make 指令。

---

## How to use hw0304

```
sudo ./hw0304 -p <pid> -a <memory_adress> 
```
Need super user to run this program.
Need PID of `DOSBOX-Staging`.
You can get the PID using this command in GNU/Linux.
```
ps aux | grep dosbox
```
And you can get the memory adress of DOSBOX by looking line output by DOSBOX-Staging like this:
> XXXX-XX-XX XX:XX:XX.XXX | MEMORY: Using 4096 DOS memory pages (16 MB) at address: 0xOOOOOOOOOOOO
and the adress is 0xOOOOOOOOOOOO, just intput include 0x.
then you can use this program.

this program can edit:
1. HP now
2. HP max
3. MP now
4. MP max
5. MT
6. DF
7. MV
8. EX
9. DX
10. item
11. magic
12. AA

you can find what they refer to in https://chiuinan.github.io/game/game/intro/ch/c31/fd2/


---

## log

---

### hw0301

#### 4/26 Finish
今天把第一題寫完了，用了 [cJSON](https://github.com/DaveGamble/cJSON) 來處理。寫信去問助教要不要輸出 book_id 中。

----

### hw0302

#### 4/26 Start
今天開始寫第二題，先把基本的處理 argument 的部分寫好。

#### 4/28 Continue
把第二題寫完了，剩下註解。

#### 4/29 Finish
把註解也解決了。但反斜線太麻煩就不寫了。

----

### hw0303

#### 4/24 Finish
今天先把第三題試著寫看看了。

#### 4/28 Debug
把第三題修好了。

----

### hw0304

#### 5/2 Star用
今天開始寫第四題，先把基本的讀入寫。

#### 5/3 Continue
今天試著把去找記憶體位置，但可能跟我想得不太一樣，我用每 16 byte 去讀的方法找不到。

#### 5/8 Find clue
今天問老師這題怎解才知道不能用 mmap，之前用那麼久都不能讀取 mmap 就是白忙一場，然後原來用 write 就可以了。

#### 5/9 Finish
今天把它完成了，記憶體原來一開始跟結尾的 8 byte 是跟前後的角色連在一起。然後發現現在的方法當主角血量或魔力超過 999 就不能再改了，因為顯示的會變 ??? 就找不到記憶體，但老師也用這個方法所以應該還好。

----

### hw0305

#### 4/29 Start
今天先把讀入的用好了。

#### 4/30 Continue
今天把第五題的點畫上去了，但還沒有連起來。
#### 5/1 Fix
今天問助教我用往上往下的連法可不可以，得到了不行，所以要改用插值法。

#### 5/2 Finish
今天把第五題寫完了，就是把每個定位點延伸成線寬，然後由外而內畫進來，然後處理漸層。
不過好像還要再修，因為寬度的算法還是有問題。

#### 5/4 Fix
今天把寬度的算法根據助教的提示修好了，然後把漸層的部分也寫好了。

#### 5/5 Fix
今天把寬小於 257 會有問題的部分修好了。

----

### hw0306

#### 5/5 Finish
今天把 bonus 完成了，然後發現黃冠寰教授的網站上有放一篇 ncurses 的教學。