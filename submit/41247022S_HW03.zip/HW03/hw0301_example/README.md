# HW0301 Example

Please make sure that your program output can be exactly matched with the provided output file `out`.

```
$ ./hw0301 < in.txt > out.txt
```