hw04
===

### 41247022S 林德恩

---

## How to build my code
在 HW04 directory 下 make 指令。

---

## log

---

### hw0401

#### 05/15 Finish
用了 `top` 跟 `awk` 以及 `head` 跟 `tail` 來取得資訊。

----

### hw0402

#### 05/16 Finish
基本上就是使用 `awk`, `wget`, `sed`, `grep` 來取得資訊，`head` 來指定輸出數量。

----

### hw0403

----

### bonus (hw0404~hw0407)

#### 05/19 Finish
今天把所有 bonus 都寫完了。