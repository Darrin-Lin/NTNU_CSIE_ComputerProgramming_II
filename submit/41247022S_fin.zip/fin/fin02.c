#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <getopt.h>
#include "mybmp.h"



int main(int argc, char *argv[])
{
    // int opt;
    // struct option longopts[] = {
    //     {"help", no_argument, NULL, 'h'},
    //     {0, 0, 0, 0}};
    // while ((opt = getopt_long(argc, argv, "h", longopts, NULL)) != -1)
    // {
    //     if(opt == 'h')
    //     {
    //         fprintf(stdout, HELP_MSG);
    //         return 0;
    //     }
    //     else
    //     {
    //         fprintf(stdout, HELP_MSG);
    //         return 0;
    //     }
    // }

    return 0;
}