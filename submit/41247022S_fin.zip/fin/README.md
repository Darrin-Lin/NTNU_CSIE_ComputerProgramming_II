fin
===

### 41247022S 林德恩

---

## How to build my code
在 fin directory 下 make 指令。

---

## log

---

### fin01

----

### fin02

----

### fin03

----

### fin04

----

### fin05

----

### fin06