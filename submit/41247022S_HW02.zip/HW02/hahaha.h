#define haha system
#define pp "python3 "
#define ppp ".py"