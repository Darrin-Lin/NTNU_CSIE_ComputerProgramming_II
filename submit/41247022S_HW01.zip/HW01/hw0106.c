#include<stdio.h>
#include<stdbit.h>
int main()
{
    _BitInt(1) a = 1;
   return 0;
}  