#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <stdint.h>

#define fptf fprintf
#define DEBUG 0

typedef struct _sRoom
{
    uint32_t cost;
    uint8_t doors; // 8 bits: aabbccdd
    // aa: the up door number 0-3
    // bb: the right door number 0-3
    // cc: the down number 0-3
    // dd: the left door number 0-3
} sRoom;

typedef struct _sPoint
{
    uint32_t row;
    uint32_t col;
} sPoint;

typedef struct _sPath
{
    uint32_t length; // Path length.
    uint32_t cost;   // Cost
    sPoint *pPath;   // An array of all points in order.
} sPath;

// The start point is pMaze[0][0] and the exit point is pMaze[row -1][col -1]
// If there is no path , return 0; If there is any errors in inputs , return -1; otherwise, return 1;
int32_t find_min_path(const sRoom *pMaze, const uint8_t row, const uint8_t col, sPath *pMinPath);

static int32_t find_path(int16_t x, int16_t y, sPath *steps, const sRoom *pMaze, const uint8_t row, const uint8_t col, int64_t *map);
// static int8_t run_path(int16_t x, int16_t y, sPath *steps, const sRoom *pMaze, const uint8_t row, const uint8_t col, sPoint **ppPath, uint32_t *size);

static int32_t find_path(int16_t x, int16_t y, sPath *steps, const sRoom *pMaze, const uint8_t row, const uint8_t col, int64_t *map)
{

    if (x < 0 || x >= col || y < 0 || y >= row)
    {
        // fptf(stderr, "err0");
        return -1;
    }
    if (*(map + y * col +x) != 0)
    {
        if (DEBUG)
        {
            fptf(stderr, "x:%d y:%d cost:%ld\n", x, y, *(map + y * col + x));
        }
        return *(map + y * col + x);
    }
    if (x == 0 && y == 0)
    {
        (steps + y * col + x)->cost = (pMaze + y * col + x)->cost;
        (steps + y * col + x)->length = 1;
        (steps + y * col + x)->pPath = calloc(1, sizeof(sPoint));
        (steps + y * col + x)->pPath[0].col = x;
        (steps + y * col + x)->pPath[0].row = y;
        *(map + y * col + x) = (steps + y * col + x)->cost;
        return (steps + y * col + x)->cost;
    }
    *(map + y * col + x) = -1;
    int32_t up = 0, down = 0, left = 0, right = 0;
    fptf(stderr, "-- x:%d y:%d %d\n", x, y, *(map + y * col + x));
    if (y - 1 >= 0 && *(map + (y - 1) * col + x) != -1)
    {
        uint8_t tempNOW = (pMaze + y * col + x)->doors & (uint8_t)0b11000000;
        uint8_t tempUP = (pMaze + (y - 1) * col + x)->doors & (uint8_t)0b00001100;
        fptf(stderr, "up:%hhu %hhu\n", tempNOW, tempUP);
        // fptf(stderr, "up:%hhu %hhu\n", tempNOW >> 6, tempUP >> 2);
        // fptf(stderr, "up:%hhu %hhu\n", ((pMaze + y * col + x)->doors & (uint8_t)0b11000000) >> 6), ((pMaze[(y - 1) * col + x].doors));
        // fptf(stderr, "%hhu", pMaze[(y - 1) * col + x].doors);
        fptf(stderr, "up %d %d %d\n", x, y, *(map + (y - 1) * col + x));
        if (tempNOW >> 6 == tempUP >> 2)
            up = find_path(x, y - 1, steps, pMaze, row, col, map);
    }
    if (x - 1 >= 0 && *(map + y * col + x - 1) != -1)
    {
        uint8_t tempNOW = (pMaze + y * col + x)->doors & (uint8_t)0b00000011;
        uint8_t tempLEFT = (pMaze + (y * col + x - 1))->doors & (uint8_t)0b00110000;
        fptf(stderr, "left:%hhu %hhu\n", tempNOW, tempLEFT);
        // fptf(stderr, "left:%hhu %hhu\n", tempNOW, tempLEFT >> 4);
        // fptf(stderr,"left %p %p",(pMaze + y * col + x ),(pMaze + y * col + x - 1));
        // fptf(stderr, "left:%hhu %hhu\n", ((pMaze + y * col + x)->doors & (uint8_t)0b00000011)), ((pMaze[y * col + x - 1].doors));
        // fptf(stderr,"%hhu",pMaze[y * col + x - 1].doors);
        fptf(stderr, "left %d %d %d\n", x, y, *(map + y * col + x - 1));
        if (tempNOW == tempLEFT >> 4)
            left = find_path(x - 1, y, steps, pMaze, row, col, map);
    }
    if (x + 1 < col && *(map + y * col + x + 1) != -1)
    {
        uint8_t tempNOW = (pMaze + y * col + x)->doors & (uint8_t)0b00110000;
        uint8_t tempRIGHT = (pMaze + (y * col + x + 1))->doors & (uint8_t)0b00000011;
        fptf(stderr, "right:%hhu %hhu\n", tempNOW, tempRIGHT);
        // fptf(stderr, "right:%hhu %hhu\n", tempNOW >> 4, tempRIGHT);
        // fptf(stderr, "right:%hhu %hhu\n", (uint8_t)((pMaze + y * col + x)->doors & (uint8_t)0b00110000) >> 4), ((pMaze[y * col + x + 1].doors));
        // fptf(stderr, "%hhu",pMaze[y * col + x + 1].doors);
        fptf(stderr, "right %d %d %d\n", x, y, *(map + y * col + x + 1));
        if (tempNOW >> 4 == tempRIGHT)
            right = find_path(x + 1, y, steps, pMaze, row, col, map);
    }
    if (y + 1 < row && *(map + (y + 1) * col + x) != -1)
    {
        uint8_t tempNOW = (pMaze + y * col + x)->doors & (uint8_t)0b00001100;
        uint8_t tempDOWN = (pMaze + (y + 1) * col + x)->doors & (uint8_t)0b11000000;
        fptf(stderr, "down:%hhu %hhu\n", tempNOW, tempDOWN);
        // fptf(stderr, "down:%hhu %hhu\n", tempNOW >> 2, tempDOWN >> 6);
        // fptf(stderr, "down:%hhu %hhu\n", ((pMaze + y * col + x)->doors & (uint8_t)0b00001100) >> 2), ((pMaze [(y + 1) * col + x].doors));
        // fptf(stderr, "%hhu",pMaze[(y + 1) * col + x].doors);
        fptf(stderr, "down %d %d %d\n", x, y, *(map + (y + 1) * col + x));
        if (tempNOW >> 2 == tempDOWN >> 6)
            down = find_path(x,y+1,steps,pMaze,row,col,map);
    }

    if (up == 0 && down == 0 && left == 0 && right == 0)
    {
        *(map + y * col + x) = -1;
        (steps + y * col + x)->cost = 0;
        // fptf(stderr, "err1\n");
        return -1;
    }
    int8_t position = 0; // 1:up 2:right 3:down 4:left
    int32_t min = up == -1 ? 0 : up;
    position = up == -1 ? 0 : 1;
    if (down != 0 && (min == 0 || down < min) && down != -1)
    {
        position = 3;
        min = down;
    }
    if (left != 0 && (min == 0 || left < min) && left != -1)
    {
        position = 4;
        min = left;
    }
    if (right != 0 && (min == 0 || right < min) && right != -1)
    {
        position = 2;
        min = right;
    }
    if (DEBUG)
    {
        fptf(stderr, "l:%d r:%d u:%d d:%d min:%d\n", left, right, up, down, min);
    }
    if (min == 0)
    {
        *(map + y * col + x) = -1;
        (steps + y * col + x)->cost = 0;
        // fptf(stderr, "err2");
        return -1;
    }
    // fptf(stderr,"%d %d pos:%d\n",x,y,position);
    if (position == 1)
    {
        (steps + y * col + x)->length = (steps + (y - 1) * col + x)->length + 1;
        (steps + y * col + x)->pPath = calloc((steps + y * col + x)->length, sizeof(sPoint));
        for (uint32_t i = 0; i < (steps + (y - 1) * col + x)->length; i++)
        {
            (steps + y * col + x)->pPath[i].col = (steps + (y - 1) * col + x)->pPath[i].col;
            (steps + y * col + x)->pPath[i].row = (steps + (y - 1) * col + x)->pPath[i].row;
        }
        (steps + y * col + x)->pPath[(steps + y * col + x)->length - 1].col = x;
        (steps + y * col + x)->pPath[(steps + y * col + x)->length - 1].row = y;
    }
    else if (position == 2)
    {
        (steps + y * col + x)->length = (steps + y * col + x + 1)->length + 1;
        (steps + y * col + x)->pPath = calloc((steps + y * col + x)->length, sizeof(sPoint));
        for (uint32_t i = 0; i < (steps + y * col + x + 1)->length; i++)
        {
            (steps + y * col + x)->pPath[i].col = (steps + y * col + x + 1)->pPath[i].col;
            (steps + y * col + x)->pPath[i].row = (steps + y * col + x + 1)->pPath[i].row;
        }
        (steps + y * col + x)->pPath[(steps + y * col + x)->length - 1].col = x;
        (steps + y * col + x)->pPath[(steps + y * col + x)->length - 1].row = y;
    }
    else if (position == 3)
    {
        (steps + y * col + x)->length = (steps + (y + 1) * col + x)->length + 1;
        (steps + y * col + x)->pPath = calloc((steps + y * col + x)->length, sizeof(sPoint));
        for (uint32_t i = 0; i < (steps + (y + 1) * col + x)->length; i++)
        {
            (steps + y * col + x)->pPath[i].col = (steps + (y + 1) * col + x)->pPath[i].col;
            (steps + y * col + x)->pPath[i].row = (steps + (y + 1) * col + x)->pPath[i].row;
        }
        (steps + y * col + x)->pPath[(steps + y * col + x)->length - 1].col = x;
        (steps + y * col + x)->pPath[(steps + y * col + x)->length - 1].row = y;
    }
    else if (position == 4)
    {
        (steps + y * col + x)->length = (steps + y * col + x - 1)->length + 1;
        (steps + y * col + x)->pPath = calloc((steps + y * col + x)->length, sizeof(sPoint));
        for (uint32_t i = 0; i < (steps + y * col + x - 1)->length; i++)
        {
            (steps + y * col + x)->pPath[i].col = (steps + y * col + x - 1)->pPath[i].col;
            (steps + y * col + x)->pPath[i].row = (steps + y * col + x - 1)->pPath[i].row;
        }
        (steps + y * col + x)->pPath[(steps + y * col + x)->length - 1].col = x;
        (steps + y * col + x)->pPath[(steps + y * col + x)->length - 1].row = y;
    }
    if (up != min && y - 1 >= 0 && up != -1)
    {
        *(map + (y - 1) * col + x) = -1;
        (steps + (y - 1) * col + x)->cost = 0;
        if ((steps + (y - 1) * col + x)->pPath != NULL)
        {
            free((steps + (y - 1) * col + x)->pPath);
        }
        (steps + (y - 1) * col + x)->pPath = NULL;
        (steps + (y - 1) * col + x)->length = 0;
    }
    if (right != min && x + 1 < col && right != -1)
    {
        *(map + y * col + x + 1) = -1;
        (steps + y * col + x + 1)->cost = 0;
        if ((steps + y * col + x + 1)->pPath != NULL)
        {
            free((steps + y * col + x + 1)->pPath);
        }
        (steps + y * col + x + 1)->pPath = NULL;
        (steps + y * col + x + 1)->length = 0;
    }
    if (down != min && y + 1 < row && down != -1)
    {
        *(map + (y + 1) * col + x) = -1;
        (steps + (y + 1) * col + x)->cost = 0;
        if ((steps + (y + 1) * col + x)->pPath != NULL)
        {
            free((steps + (y + 1) * col + x)->pPath);
        }
        (steps + (y + 1) * col + x)->pPath = NULL;
        (steps + (y + 1) * col + x)->length = 0;
    }
    if (left != min && x - 1 >= 0 && left != -1)
    {
        *(map + y * col + x - 1) = -1;
        (steps + y * col + x - 1)->cost = 0;
        if ((steps + y * col + x - 1)->pPath != NULL)
        {
            free((steps + y * col + x - 1)->pPath);
        }
        (steps + y * col + x - 1)->pPath = NULL;
        (steps + y * col + x - 1)->length = 0;
    }

    (steps + y * col + x)->cost = min + (pMaze + y * col + x)->cost;
    *(map + y * col + x) = (steps + y * col + x)->cost;
    if (DEBUG)
    {
        fptf(stderr, "x:%d y:%d cost:%d\n", x, y, (steps + y * col + x)->cost);
    }
    return min + (pMaze + y * col + x)->cost;
}
/*
static int8_t run_path(int16_t x, int16_t y, sPath *steps, const sRoom *pMaze, const uint8_t row, const uint8_t col, sPoint **ppPath, uint32_t *size)
{
    if (x < 0 || x >= col || y < 0 || y >= row)
    {
        return -1;
    }
    if (x == col - 1 && y == row - 1)
    {
        (*size)++;
        sPoint *temp = NULL;
        temp = realloc(*ppPath, sizeof(sPoint) * (*size));
        if (temp == NULL)
            return -1;
        *ppPath = temp;
        (*ppPath + (*size) - 1)->col = x;
        (*ppPath + (*size) - 1)->row = y;
        return 0;
    }
    if ((steps + y * col + x + 1)->cost != -1)
    {
        (*size)++;
        sPoint *temp = NULL;
        temp = realloc(*ppPath, sizeof(sPoint) * (*size));
        if (temp == NULL)
            return -1;
        *ppPath = temp;
        (*ppPath + (*size) - 1)->col = x;
        (*ppPath + (*size) - 1)->row = y;

        return run_path(x + 1, y, steps, pMaze, row, col, ppPath, size);
    }
    else if ((steps + (y + 1) * col + x)->cost != -1)
    {
        (*size)++;
        sPoint *temp = NULL;
        temp = realloc(*ppPath, sizeof(sPoint) * (*size));
        if (temp == NULL)
            return -1;
        *ppPath = temp;
        (*ppPath + (*size) - 1)->col = x;
        (*ppPath + (*size) - 1)->row = y;

        return run_path(x, y + 1, steps, pMaze, row, col, ppPath, size);
    }
    else if ((steps + (y - 1) * col + x)->cost != -1)
    {
        (*size)++;
        sPoint *temp = NULL;
        temp = realloc(*ppPath, sizeof(sPoint) * (*size));
        if (temp == NULL)
            return -1;
        *ppPath = temp;
        (*ppPath + (*size) - 1)->col = x;
        (*ppPath + (*size) - 1)->row = y;

        return run_path(x, y - 1, steps, pMaze, row, col, ppPath, size);
    }
    else if ((steps + y * col + x - 1)->cost != -1)
    {
        (*size)++;
        sPoint *temp = NULL;
        temp = realloc(*ppPath, sizeof(sPoint) * (*size));
        if (temp == NULL)
            return -1;
        *ppPath = temp;
        (*ppPath + (*size) - 1)->col = x;
        (*ppPath + (*size) - 1)->row = y;

        return run_path(x - 1, y, steps, pMaze, row, col, ppPath, size);
    }
    return 0;
}
*/
int32_t find_min_path(const sRoom *pMaze, const uint8_t row, const uint8_t col, sPath *pMinPath)
{
    if (pMaze == NULL || row == 0 || col == 0)
    {
        return -1;
    }
    for (uint8_t i = 0; i < row; i++)
    {
        for (uint8_t j = 0; j < col; j++)
        {
            fptf(stderr, "door:%hhu\n", (pMaze + i * col + j)->doors);
        }
    }
    int64_t map[row * col];
    for (uint8_t i = 0; i < row; i++)
    {
        for (uint8_t j = 0; j < col; j++)
        {
            map[i * col + j] = 0;
            // fptf(stderr, "idx:%d\n", i * col + j);
        }
    }
    sPath steps[row * col];
    for (uint8_t i = 0; i < row; i++)
    {
        for (uint8_t j = 0; j < col; j++)
        {
            steps[i * col + j].cost = 0;
            steps[i * col + j].pPath = NULL;
            steps[i * col + j].length = 0;
        }
    }
    int64_t cost = find_path(col - 1, row - 1, steps, pMaze, row, col, map);
    if (cost == -1)
    {
        // fptf(stderr, "aaa");
        return 0;
    }
    /*sPoint *pPath = NULL;
    pPath = calloc(0, sizeof(sPoint));
    uint32_t size = 0;*/
    // for (uint32_t i = 0; i < row; i++)
    // {
    //     for (int j = 0; j < col; j++)
    //     {
    //         fptf(stderr, "map:%ld\n", map[i * col + j]);
    //         fptf(stderr, "cost:%d\n", steps[i * col + j].cost);
    //         for (uint32_t k = 0; k < steps[i * col + j].length; k++)
    //         {
    //             fptf(stderr, "(%d,%d) \n", steps[i * col + j].pPath[k].col, steps[i * col + j].pPath[k].row);
    //         }
    //     }
    //     fptf(stderr, "\n");
    // }
    /*
    run_path(0, 0, steps, pMaze, row, col, &pPath, &size);
    sPoint path[size];
    for (uint32_t i = 0; i < size; i++)
    {
        path[i].col = (pPath + i)->col;
        path[i].row = (pPath + i)->row;
    }
    free(pPath);*/
    pMinPath->cost = cost;
    pMinPath->length = steps[row * col - 1].length;
    pMinPath->pPath = steps[row * col - 1].pPath;
    // sPoint path_array[steps[row * col- 1].length];
    // for (uint32_t i = 0; i < steps[row * col- 1].length; i++)
    // {
    //     path_array[i].row = steps[row * col- 1].pPath[i].row;
    //     path_array[i].col = steps[row * col- 1].pPath[i].col;
    // }
    // pMinPath->pPath = path_array;
    for (uint8_t i = 0; i < row * col - 1; i++)
    {
        if (steps[i].pPath != NULL)
        {
            free(steps[i].pPath);
        }
    }

    return 1;
}